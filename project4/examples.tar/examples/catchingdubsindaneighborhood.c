int dead(); 

int killingspiders(int dn, int *y) {
    int i, mangoes, urmom, *p;
    for(i = 0; i < 10; i = i + 1) {
        mangoes = 5;
    }
    break; /*break statement not within loop*/

    while (i < 100) {
        i = i * 10; 
        if ( i == 20) {
            break;
            
            urmom = 0;
            while ( urmom != 1) {
                break;
                break;  
            }
        }
    }
    break; /*break statement not within loop*/
    return p; /*invalid return type*/
}

int * urmotherisurfather(int g, int neighbors, int daboys) {
    int a, b, c, d;
    int *e, *f, *g, *h; /*redeclaration of g*/
    /*logical expr*/
    d = a || b;
    a = b && d;
    /*equality and relational expr*/
    e = b == f; /*invalid operands to binary %s*/
    e = b != f; /*invalid operands to binary %s*/
    e = b <= f; /*invalid operands to binary %s*/
    e = b >= f; /*invalid operands to binary %s*/
    e = b < f; /*invalid operands to binary %s*/
    e = b > f; /*invalid operands to binary %s*/

    f = h + f; /*invalid operands to binary %s*/
    f = a - f; /*invalid operands to binary %s*/

    f = e * f; /*invalid operands to binary %s*/
    e = e / f; /*invalid operands to binary %s*/
    e = e % f; /*invalid operands to binary %s*/

    a = !e;  /*invalid operand to unary %s*/
    a = -e; /*invalid operand to unary %s*/
    a = *a; /*invalid operand to unary %s*/
    a = &1; /*lvalue required in expression*/
    a = sizeof dead; /*invalid operand to unary %s"*/
    
}