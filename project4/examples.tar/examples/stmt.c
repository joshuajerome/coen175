int **f(void)
{
    int *p;
    return p;			/* invalid return type */
}

int main(void)
{
    break;			/* break statement not within loop */

    while (1)
	break;
}
