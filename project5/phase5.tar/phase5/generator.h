# ifndef GENERATOR_H
# define GENERATOR_H

# include "Tree.h"
# include "Symbol.h"

void generateGlobals(Scope *scope);

# endif