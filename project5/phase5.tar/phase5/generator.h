# ifndef GENERATOR_H
# define GENERATOR_H

# include "Tree.h"
# include "Symbol.h"
# include "Scope.h"

void generateGlobals(Scope *scope);

# endif
