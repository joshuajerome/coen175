# ifndef CHECKER_h
# define CHECKER_h
# include <iostream>

using namespace std;

void openScope() {
    cout << "open scope" << endl;
}

void closeScope() {
    cout << "close scope" << endl;
}

void defineFunction();

void declareSymbol();

void checkIdentifier();

# endif