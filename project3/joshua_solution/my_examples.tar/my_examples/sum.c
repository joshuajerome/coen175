int sum(int a, int b) {

	goo();
	return a + b;
}
