int test(void) {
	int x, *p, f(), (*q)();
	char a[10], b[10][20];
}
