int test(void) {
	int *p, x, f(), (*q)();
	char a[10], b[10][20];
}
